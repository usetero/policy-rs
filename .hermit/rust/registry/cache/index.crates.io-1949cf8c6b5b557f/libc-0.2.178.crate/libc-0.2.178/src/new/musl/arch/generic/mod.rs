//! Source directory: `arch/generic/`
//!
//! <https://github.com/kraj/musl/tree/master/arch/generic>

pub(crate) mod bits {
    // Currently unused
}
