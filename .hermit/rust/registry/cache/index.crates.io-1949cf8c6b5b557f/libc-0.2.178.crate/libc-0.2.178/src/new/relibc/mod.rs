//! Redox OS libc.
//!
//! * Headers: <https://gitlab.redox-os.org/redox-os/relibc>

pub(crate) mod unistd;
