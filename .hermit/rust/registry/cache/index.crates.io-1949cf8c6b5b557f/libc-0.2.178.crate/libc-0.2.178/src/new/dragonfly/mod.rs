//! DragonFly BSD libc.
//!
//! * Headers: <https://github.com/DragonFlyBSD/DragonFlyBSD>
//! * Manual pages: <https://leaf.dragonflybsd.org/cgi/web-man>

pub(crate) mod unistd;
