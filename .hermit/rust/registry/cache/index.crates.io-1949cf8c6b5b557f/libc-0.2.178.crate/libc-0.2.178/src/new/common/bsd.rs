//! Interfaces common across the BSD family.
