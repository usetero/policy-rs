//! Directory: `sys/`
//!
//! https://github.com/openbsd/src/tree/trunk/sys/sys

pub(crate) mod ipc;
