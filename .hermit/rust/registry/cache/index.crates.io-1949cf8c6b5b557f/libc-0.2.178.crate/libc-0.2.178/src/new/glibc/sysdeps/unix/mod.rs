//! Source directory: `sysdeps/unix/`
//!
//! <https://github.com/bminor/glibc/tree/master/sysdeps/unix>

#[cfg(target_os = "linux")]
pub(crate) mod linux;
