//! Source directory: `arch/mips/`
//!
//! <https://github.com/kraj/musl/tree/master/arch/mips>

pub(crate) mod bits {
    pub(crate) mod socket;
}
