//! VxWorks libc.
// FIXME(vxworks): link to headers needed.

pub(crate) mod unistd;
